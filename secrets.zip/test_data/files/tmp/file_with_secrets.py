#!/usr/bin/python
# Will change this later.
SUPER_SECRET_VALUES = '60b725f10c9c85c70d97880dfe8191b3', '3b5d5c3712955042212316173ccf37be'


def main():
    print('Hello world!')


if __name__ == '__main__':
    main()
