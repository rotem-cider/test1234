#!/usr/bin/python
# Will change this later.
SUPER_SECRET_VALUE = 'this is just a long string, like a user facing error message'


def main():
    print('Hello world!')


if __name__ == '__main__':
    main()
