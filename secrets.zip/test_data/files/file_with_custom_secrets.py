#!/usr/bin/python
REGULAR_VALUE = 'this is just a long string, like a user facing error message'
FOOD = 'sweet potato casserole'
ANIMAL = 'Hippo'
