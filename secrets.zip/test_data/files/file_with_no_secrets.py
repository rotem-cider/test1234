#!/usr/bin/python
REGULAR_VALUE = 'this is just a long string, like a user facing error message'


def main():
    print('Hello world!')


if __name__ == '__main__':
    main()
