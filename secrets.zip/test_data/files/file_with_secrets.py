#!/usr/bin/python
# Will change this later.
SUPER_SEECRET_VALUE = 'c3VwZXIgbG9uZyBzdHJpbmcgc2hvdWxkIGNhdXNlIGVub3VnaCBlbnRyb3B5'
VERY_SECRET_TOO = 'f6CGV4aMM9zedoh3OUNbSakBymo7yplB'  # pragma: allowlist secret


def main():
    print('Hello world!')


if __name__ == '__main__':
    main()
