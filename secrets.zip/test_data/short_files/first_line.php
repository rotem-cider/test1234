secret = 'notHighEnoughEntropy'
skipped_sequential_false_positive = '0123456789a'
print('second line')
var = 'third line'
